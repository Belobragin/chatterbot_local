This is a local chatterbot version, does not require web downloads.
#######################
